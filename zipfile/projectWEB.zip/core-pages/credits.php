<?php
/* --------------------------------------------------------------------------------------
                                     CREDITS
   Credits         : phpSGEx by Aldrigo Raffaele
   Last modified by: Raffa50 01.03.2014
   Comments        : added REMOVE
-------------------------------------------------------------------------------------- */
//DO NOT REMOVE/EDIT THIS FILE OR YOU WILL BE LEGALLY REPORTED AND YOUR WORK WILL BE CANCELLED

$body.="phpSGE coded by Aldrigo Raffaele 'Raffa50', PhpSgeX is only a new version of phpSGE<br>
DO NOT MODIFY OR REMOVE THE FOOTER. DO NOT DELETE ALDRIGO RAFFAELE'S NAME<br>
Give the rights of your work also to Aldrigo Raffaele and phpSGE DevTeam.<br>
phpSGE is under license and your work can be cancelled.<br>
<b>phpSGE is 100% free and you aren't allowed to make money with it.
If you want to buy phpSgeX commercial license (and make money) contact Aldrigo Raffaele</b> (email: reloader90@gmail.com)
or look at this topic if you want to know the conditions: <a href='http://phpstrategygame.sourceforge.net/phpBB3/viewtopic.php?f=3&p=85#p85'>PhpSge Commercial License Topic link</a>  <br><br>
You can edit phpSGE code<br><br>
If you made a mod it's a donation, and you can't claim phpSGE as yours (and you aren't allowed to make a similar project)<br>
You also agree all rules on the PhpSge site: <a href='http://phpstrategygame.sourceforge.net/'>http://phpstrategygame.sourceforge.net/</a> <br> <br>

<b>ADDITIONAL CREDITS</b>: <br>
- Vladimir Zaikin (Vlad) : Russian translation <br>
- Ramon Schepers (Schepers12) : Tester & General helper & Reporter <br>
- Tobias Strunz (Fhizban) : Developer <br>
";
?>