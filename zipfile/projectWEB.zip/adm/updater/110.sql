INSERT INTO `tutorial` (`id`, `tittle`, `body`, `next_tut`) VALUES (1, 'Welcome', 'Welcome to phpSGE! This is the tutorrial', 2);
UPDATE `conf` SET `sge_ver` = '111' WHERE `sge_ver` = '110';