<?php
define("CONFVER", 101);
define("DBVER", 124);
define("SGEXVER", "2.0.3.3");
//error_reporting('E_NONE'); //comment in release, enable in debug
?>