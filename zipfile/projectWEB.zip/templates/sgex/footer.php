<?php
if( !isset($path) ) $path="";
?>
<div class="art-footer">
	<div class="art-footer-t"></div>
	<div class="art-footer-l"></div>
	<div class="art-footer-b"></div>
	<div class="art-footer-r"></div>
	<div class="art-footer-body">
	<div class="art-footer-text">
		<!-- WARNING: you aren't allowed to edit/remove this footer, if you edit it you can be legally reported and your work will be cancelled -->
		<div>PhpSgeX by <a href="http://aldrigo.sf.net">Aldrigo Raffaele</a> and <a href="?pg=credits">phpSGE DevTeam</a> © 2015. Based on phpSGE.</div>
		<div align="center">
        <table border='0'><tr><td>
			<a href='https://sourceforge.net/projects/phpstrategygame'><img src="<?=$path;?>favicon.ico" height="31px" width="31px" /></a>
			<a href='https://sourceforge.net/p/phpstrategygame/donate/'><img src="<?=$path;?>img/project-support.jpg" /> </a>
			<a href='http://soft82.com'><img src="<?=$path;?>img/soft82_award.gif" /></a>
            </td>
			<td> <a href='http://www.w3.org/'><img src='<?=$path;?>img/w3c-html5.png' /></a> </td>
			<td>
				<a href='http://php.net'><img src="<?=$path;?>img/logo-php.png" style='margin: 0px;' /></a><br>
				<a href='http://mysql.com'><img src="<?=$path;?>img/logo-mysql.png" style='margin: 0px;' /></a>
            </td><td>
            <a href='http://creativecommons.org/licenses/by-nc-sa/4.0/'><img src="<?=$path;?>img/cc.png" style='margin: 0px;' /></a>
            <a href='https://sourceforge.net/p/phpstrategygame'><img src='<?=$path;?>img/sflogo.gif' style='...'/></a>
            </td>
			<td>
				<!-- PAGERANKTOP.COM START CODE -->
				<script src="http://s5.pageranktop.com/pr.php?id=7840&type=jsc"></script>
				<!-- PAGERANKTOP.COM END CODE -->
			</td>
        </tr></table>
        </div>
		<!-- WARNING END -->
    </div>
    <div class="cleared"></div>
    </div>
</div>